﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    struct Operation
    {
        public int number;

        public void getValues(int a)
        {
            number = a;
        }

        public void squaredisplay(int number)
        {
            Console.WriteLine("Square is " + (number * number));

        }

        public void cubedisplay(int number)
        {
            Console.WriteLine("Cube is " + (number * number * number));
        }
    };


    class Program
    {
        static void Main(string[] args)
        {
                Operation obj = new Operation();
                Console.WriteLine("Enter the number");
                int a =Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter your choice 1 or 2");
                int choice= Convert.ToInt32(Console.ReadLine());
            switch (choice)
                {
                    case 1:
                        obj.squaredisplay(a);
                        break;

                    case 2:
                        obj.cubedisplay(a);
                        break;

                }

        }
    }
}
